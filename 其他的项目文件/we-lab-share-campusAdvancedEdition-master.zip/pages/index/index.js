let app = getApp()
let token = wx.getStorageSync('token')
import Toast from 'miniprogram_npm/@vant/weapp/toast/toast'
Page({
  data: {
    state: '',
  },

  onLoad() {
    let that = this

    
    //检查登录情况
    if (!token) {
      wx.navigateTo({
        url: '/pages/login/login',
      })
    }else{
      app.globalData.identification=token.identification
      app.globalData.number=token.number
      app.globalData.user_id=token.user_id
      app.globalData.name=token.name
    }
  },


  go2equip: function (param) {
    wx.navigateTo({
      url: '/pages/equip/equip?category=equipment',
    })
  },
  go2room: function (param) {
    wx.navigateTo({
      url: '/pages/equip/equip?category=lab',
    })
  },
  go2feedback: function (param) {
    wx.navigateTo({
      url: '/pages/equip/equip?category=workplace',
    })
  },
  

  go2info: function (param) {
    wx.navigateTo({
      url: '/pages/info_center/info_center',
    })
  },

  go2announcementList: function (e) {
    //this.subscribe()
    wx.navigateTo({
      url: '/pages/announcement_list/announcement_list?kind=' + e.currentTarget.dataset.messages
    })
  },
  go2guidance: function (e) {
    wx.navigateTo({
      url: '/pages/guidance/guidance',
    })
  },
  go2award:function(e){
    wx.navigateTo({
      url: '/pages/award/award',
    })
  },
})
