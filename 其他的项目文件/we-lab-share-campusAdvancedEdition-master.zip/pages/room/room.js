// pages/room/room.js
Page({

  data: {
    //存储用于展示的学院名
    academy:[],
    //存储用于展示的功能名
    usage:[],
    //存储用于展示每个活动室的具体信息
   lab:[],
   
  },

  //从云数据库中得到数据并析除具有相同学院或功能的数据（用于展示在下拉menu的选项中的）
  getData:function getData(params) {
    let that = this
    wx.cloud.database({env:"welab-0g7lv9me1d812eb0"}).collection("lab").get({
      success(res){
        let length = res.data.length
        let academy = []
        let usage = []
        for(let i = 0; i<length ; ++i){
          const temp = {text:res.data[i].academy,value:res.data[i].academy}
          const temp2 = {text:res.data[i].usage,value:res.data[i].usage}
          academy.push(temp)
          usage.push(temp2)
        }
        let name = []
        let name2 = []
        let new_academy = []
        let new_usage = []
        for(let i in academy){
          if(name.indexOf(academy[i].text) == -1){
            name.push(academy[i].text)
            new_academy.push(academy[i])
          }
        }
        for(let i in usage){
          if(name2.indexOf(usage[i].text) == -1){
            name2.push(usage[i].text)
            new_usage.push(usage[i])
          }
        }
        that.setData({
          academy:new_academy,
          usage:new_usage
        })
      }
    })
  },

  //筛选学院
  select1(value) {
    let that = this
    let name = value.detail
    let academy = []
    wx.cloud.database({env:"welab-0g7lv9me1d812eb0"}).collection("lab").get({
      success(res){
        for(let i = 0; i<res.data.length ; ++i){
          const temp = res.data[i]
          academy.push(temp)
        }
        let lab = academy.filter(function(obj){
           return obj.academy == name
        })
        that.setData({
          lab
        })
      }
    })
  },

  //筛选功能
  select2(value){
    let that = this
    let name = value.detail
    let usage = []
    wx.cloud.database({env:"welab-0g7lv9me1d812eb0"}).collection("lab").get({
      success(res){
        for(let i = 0; i<res.data.length ; ++i){
          const temp = res.data[i]
          usage.push(temp)
        }
        let lab = usage.filter(function(obj){
           return obj.usage == name
        })
        that.setData({
          lab
        })
      }
    })
  },

  //跳转到具体器材页面
  go2equipment_detail:function(e){
    let curName = e.currentTarget.dataset.messages.name
    let curPlace = e.currentTarget.dataset.messages.place
    let curAcademy = e.currentTarget.dataset.messages.academy
    let curUsage = e.currentTarget.dataset.messages.usage
    let curNameOfManager = e.currentTarget.dataset.messages.manager
    let curTeleOfManager = e.currentTarget.dataset.messages.phone
    let curId = e.currentTarget.dataset.messages._id
    console.log("当前仪器信息",curName, curPlace, curAcademy, curUsage, curNameOfManager, curTeleOfManager)
    wx.navigateTo({
      url: '/pages/equipment_detail/equipment_detail?curName=' + curName
       + '&curPlace=' + curPlace
       + '&curAcademy=' + curAcademy
       + '&curUsage=' + curUsage
       + '&curNameOfManager=' + curNameOfManager
       + '&curTeleOfManager=' + curTeleOfManager
       + '&curId=' + curId
      ,
    })
  },
  
  onLoad(options) {
    this.getData()
    let that = this
    //获取每一个活动室具体信息并展示出来
    wx.cloud.database({env:"welab-0g7lv9me1d812eb0"}).collection("lab").get({
      success(res){
        let length = res.data.length
        let lab = []
        for(let i = 0;i<length;++i){
          const temp =res.data[i]
          lab.push(temp)
        }
        that.setData({
          lab
        })
      }
    })
  },

  onReady() {

  },

  onShow() {

  },

  onHide() {

  },

  onUnload() {

  },


  onPullDownRefresh() {

  },

  
  onReachBottom() {

  },

  onShareAppMessage() {

  }
})