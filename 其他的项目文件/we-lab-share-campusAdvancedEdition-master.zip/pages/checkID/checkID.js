let check = []
import Dialog from 'miniprogram_npm/@vant/weapp/dialog/dialog';
Page({
  data: {
    check: [],
    imageID: '',
    imageTempPath: '',
  },

  //获取待认证的账号
  getAll() {
    let that = this
    return new Promise((resolve, reject) => {
      wx.cloud.database().collection("register").where({
        certificated: false
      }).get().then(res => {
        let length = res.data.length
        for (let i = 0; i < length; ++i) {
          const temp = { name: res.data[i].name, number: res.data[i].number, identification: res.data[i].identification, imageID: res.data[i].imageID, id: res.data[i]._id }
          check.push(temp)
          that.setData({
            check
          })
        }
        this.onLoad()
      })
    })
  },

  //点击展示认证图片
  showImage(e) {
    let that = this
    that.setData({
      imageID: e.currentTarget.dataset.messages.imageID
    })
    wx.showLoading({
      title: '图片加载中',
    })
    //下载图片
    wx.cloud.downloadFile({
      fileID: that.data.imageID,
    }).then(res => {
      that.setData({
        imageTempPath: res.tempFilePath
      })
      wx.hideLoading()
    }).catch(err => {
      console.log(err)
    })
    Dialog.confirm({
      title: "认证身份",
    }).then(() => {
      wx.cloud.database().collection("register").doc(e.currentTarget.dataset.messages.id).update({
        data: {
          certificated: true
        },
        success: res => {
          console.log("成功没", res)
        }
      })
    }).catch(() => {
    })
  },

  onLoad(options) {
    check = []
    this.data.check = []
    this.getAll()
  },

  onReachBottom() {

  },
  onShareAppMessage() {

  }
})