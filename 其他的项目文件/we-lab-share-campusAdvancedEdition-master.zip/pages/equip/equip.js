const app = getApp()
Page({
  data: {
     location:[
     ],
     usage:[
      
     ],
    equipment:[

    ],
    equipment1:[],
    kind:""
  },

  //从数据库中得到数据并析除具有相同学院或功能的数据（用于展示在下拉menu的选项中的）
  getData:function getData(params) {
    let that = this
    wx.request({
      url: 'https://server.itstudio.club:20443/equipment/all',
      method: 'GET',
      success(res){
        let length = res.data.data.length
        let location = []
        let capacity = []
        for(let i = 0; i<length ; ++i){
          if(res.data.data[i].kind==that.data.kind){
            const temp = {text:res.data.data[i].location,value:res.data.data[i].location}
          const temp2 = {text:res.data.data[i].capacity,value:res.data.data[i].capacity}
          location.push(temp)
          capacity.push(temp2)
          }
        }
        let name = []
        let name2 = []
        let new_location = []
        let new_capacity = []
        for(let i in location){
          if(name.indexOf(location[i].text) == -1){
            name.push(location[i].text)
            new_location.push(location[i])
          }
        }
        for(let i in capacity){
          if(name2.indexOf(capacity[i].text) == -1){
            name2.push(capacity[i].text)
            new_capacity.push(capacity[i])
          }
        }
        that.setData({
          location:new_location,
          capacity:new_capacity
        })
      }
    })
},

  //筛选学院
  select1(value) {
    let that = this
    let name = value.detail
    let location = []
    // 根据选择的学院名称筛选数据
    if (name) {
      let equipment = that.data.equipment1
      location = equipment.filter(item => item.location === name)
    } else {
      // 如果没有选择学院，则显示所有数据
      location = that.data.equipment1
    }
    that.setData({
      equipment: location
    })
  },
  

  //筛选功能
select2(value){
  let that = this
  let name = value.detail
  let capacity = []

  // 根据选择的功能名称筛选数据
  if (name) {
    let equipment = that.data.equipment1
    capacity = equipment.filter(item => item.capacity === name)
  } else {
    // 如果没有选择功能，则显示所有数据
    capacity = that.data.equipment1
  }

  that.setData({
    equipment: capacity
  })
},

  //跳转到具体器材页面
  go2equipment_detail:function(e){
    let that = this
    let curName = e.currentTarget.dataset.messages.name
    let curPlace = e.currentTarget.dataset.messages.location
    let curCapacity = e.currentTarget.dataset.messages.capacity
    let curId = e.currentTarget.dataset.messages.id
    let curImage=e.currentTarget.dataset.messages.image_url
    let brief=e.currentTarget.dataset.messages.brief
    let inside=e.currentTarget.dataset.messages.image_inside
    let disable = e.currentTarget.dataset.messages.disable
    wx.navigateTo({
      url: '/pages/equipment_detail/equipment_detail?curName=' + curName
       + '&curPlace=' + curPlace
       + '&curCapacity=' + curCapacity
       + '&curId=' + curId
       +'&curImage='+curImage
       +'&brief='+brief
       +'&inside='+inside
       +'&disable='+disable
      ,
    })
  },
  
  onLoad(options) {
    this.setData({
      kind:options.category
    })
    this.getData()
    let that = this
    wx.request({
      url: 'https://server.itstudio.club:20443/equipment/all',
      method: 'GET',
      success(res){
        let length = res.data.data.length
        let equipment = []
        for(let i = 0;i<length;++i){
          const temp =res.data.data[i]
          if(temp.kind==options.category){
            equipment.push(temp)
          }
        }
        that.setData({
          equipment,
          equipment1:equipment
        })
      }
    })
  },

  //筛选栏选择
  selectAptitudeItem : function(e){
    let newList=[]
    let chooseIndex = e.currentTarget.dataset.indexArray
    if(this.data.indexArray.indexOf(chooseIndex)==-1){
      this.data.indexArray.push(chooseIndex)
    }else{
      newList.push(chooseIndex)
    }
    this.data.indexArray = this.data.indexArray.concat(newList).filter(function(v,i,arr){
      return arr.indexOf(v) ===arr.lastIndexOf(v)
    });

    //点击选中，点击取消
    let that = this
    let data = e.currentTarget.dataset
    let index = "dropDownMenuSourceData[0].detailList[0].detailList["+data.index+"].actived"
    that.setData({
      [index]:!that.data.dropDownMenuSourceData[0].detailList[0].detailList[data.index].actived
    })
    if(chooseIndex !== 0){
      let index1 = "dropDownMenuSourceData[0].detailList[0].detailList[0].actived"
      this.setData({
        [index1]:false
      })
    }else{
      this.clickFlag()
    }
    let detailValue = that.data.dropDownMenuSourceData[0].detailList[0].detailList.filter(it => it.actived).map(it => it.selectId)
    that.setData({
      chooseArray:detailValue
    })
  },

  clickFlag(){
  this.data.indexArray.forEach(el =>{
    let index = "dropDownMenuSourceData[0].detailList[0].detailList["+el+"].actived"
    if(el == 0){
      this.setData({
        [index]:true
      })
    }else{
      this.setData({
        [index]:false
      })
    }
  });
  this.data.indexArray = []
},

  selectReset(){
  let index = "dropDownMenuSourceData[0].detailList[0].detailList[0].actived"
  this.setData({
    [index]:true,
  })
  this.clickFlag()
}
})