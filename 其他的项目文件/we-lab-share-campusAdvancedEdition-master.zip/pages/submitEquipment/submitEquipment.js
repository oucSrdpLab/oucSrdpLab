import Dialog from 'miniprogram_npm/@vant/weapp/dialog/dialog';
import Toast from 'miniprogram_npm/@vant/weapp/toast/toast';

let app =getApp()
let things = []
Page({
  data: {
    openId:'',
    things: [],
    show: false,
    name: '',
    itemName: "",
    academy: '',
    place: '',
    number: '',
    kind: '',
    brief:'',
    //update选择的修改方面（电话，姓名之类的）
    curIdOfItem:'',
    curKindOfItem:'',
    columns: ['学院', '用途', '仪器/活动室名', '地点'],
    showField: true,
    curContent:''
  },

  go2detail(){
    wx.navigateTo({
      url: '/pages/submitEquipment_detail/submitEquipment_detail',
    })
  },

  //获取仪器
  getThings() {
    let that = this;
    console.log("当前页面名字为", app.globalData.name);
    wx.request({
      url: 'https://server.itstudio.club:20443/equipment/all',
      method: 'GET',
      success: function(res) {
        console.log(res.data);
        that.setData({
          things:res.data.data
        })
      },
      fail: function(err) {
        console.error("请求失败:", err);
      }
    });
  },

    //删除仪器/活动室
    delete(e) {
      // 获取要删除的设备信息
      let id = e.currentTarget.dataset.messages.id;
      let that = this
      // 弹窗提示确认删除
      wx.showModal({
        title: '提示',
        content: '确定删除吗？',
        success: function (res) {
          if (res.confirm) {
            // 发送删除请求
            wx.request({
              url: 'https://server.itstudio.club:20443/equipment/delete',
              method: 'POST',
              header: {
                'Content-Type': 'application/json'
              },
              data: {
                equipment_id: id
              },
              success: function(res) {
                console.log('删除成功', res.data);
                // 从things中删除
                let things = that.data.things;
                let index = things.findIndex(item => item.id == id);
                things.splice(index, 1);
                // 更新页面数据
                that.setData({
                  things: things
                });
              },
              fail: function(err) {
                console.error('删除失败', err);
              }
            });
          } else if (res.cancel) {
            console.log('用户点击取消');
          }
        }
      });
    },
  
    disable(e) {
      // 获取要禁用的设备信息
      let id = e.currentTarget.dataset.messages.id;
      let that = this;
      // 弹窗提示确认禁用
      wx.showModal({
        title: '提示',
        content: '确定禁用吗？',
        success: function (res) {
          if (res.confirm) {
            // 发送禁用请求
            wx.request({
              url: 'https://server.itstudio.club:20443/equipment/disable',
              method: 'POST',
              header: {
                'Content-Type': 'application/json'
              },
              data: {
                equipment_id: id
              },
              success: function(res) {
                wx.showToast({
                  title: '禁用成功',
                  icon: 'success',
                  duration: 2000
                });
                // 更新页面数据，比如改变设备状态显示等
                // ...
              },
              fail: function(err) {
                wx.showToast({
                  title: '禁用失败',
                  icon: 'none',
                  duration: 2000
                });
                console.error('禁用失败', err);
              }
            });
          } else if (res.cancel) {
            console.log('用户点击取消');
          }
        }
      });
    },
    
    enable(e) {
      // 获取要解除禁用的设备信息
      let id = e.currentTarget.dataset.messages.id;
      let that = this;
      // 弹窗提示确认解除禁用
      wx.showModal({
        title: '提示',
        content: '确定解除禁用吗？',
        success: function (res) {
          if (res.confirm) {
            // 发送解除禁用请求
            wx.request({
              url: 'https://server.itstudio.club:20443/equipment/enable',
              method: 'POST',
              header: {
                'Content-Type': 'application/json'
              },
              data: {
                equipment_id: id
              },
              success: function(res) {
                wx.showToast({
                  title: '解除禁用成功',
                  icon: 'success',
                  duration: 2000
                });
                // 更新页面数据，比如改变设备状态显示等
                // ...
              },
              fail: function(err) {
                wx.showToast({
                  title: '解除禁用失败',
                  icon: 'none',
                  duration: 2000
                });
                console.error('解除禁用失败', err);
              }
            });
          } else if (res.cancel) {
            console.log('用户点击取消');
          }
        }
      });
    },
    

  onLoad(options) {
    this.getThings()
  },
})