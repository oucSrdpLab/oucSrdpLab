import Dialog from 'miniprogram_npm/@vant/weapp/dialog/dialog';
Page({
  data: {
    waitingAudit: [],
    all: [],
    detail:[],
    show:false
  },
  onClose(){
    this.setData({
      show:false
    })
  },

  window(e) {
    let res = e.target.dataset.messages;
    let detail = [
      { label: "申请人姓名", value: res.applicant_name },
      { label: "申请人学号", value: res.applicant_student_id },
      { label: "设备名称", value: res.equipment_name },
      { label: "申请人数", value: res.number_of_applicants },
      { label: "审核原因", value: res.review_reason },
      { label: "开始时间", value: res.start_time },
      { label: "结束时间", value: res.end_time },
      {label:"预约人联系电话",value: res.telephone}
    ];
    
    this.setData({
      show: true,
      detail: detail
    });
  },
  
  
  checkOrder(e) {
    console.log(e.target.dataset.messages);
    let res = e.target.dataset.messages;
    let is_checked = e.target.dataset.is_checked == 'primary' ? 1 : 2;
    let that = this
    wx.request({
      url: 'https://server.itstudio.club:20443/appointment/edit',
      method: 'POST',
      data: {
        appointment_id: res.id,
        is_checked: is_checked
      },
      success: function(res) {
        console.log("请求成功:", res.data);
        
        if (is_checked == 1) {
          wx.showToast({
            title: '已同意',
            icon: 'success',
            duration: 2000
          });
        } else {
          wx.showToast({
            title: '已不同意',
            icon: 'none',
            duration: 2000
          });
        }
        that.onLoad()
      },
      fail: function(error) {
        console.log("请求失败:", error);
      }
    });
  },
  
  

  onLoad(options) {
    let that = this;
    // 获取当前日期对象
    var currentDate = new Date();
  
    // 设置开始时间为当天的 00:00:00
    var startTime = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate(), 0, 0, 0);
  
    // 设置结束时间为当天的 23:59:59
    var endTime = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate(), 23, 59, 59);
    // 将结束时间增加3天
    endTime.setDate(endTime.getDate() + 30);
  
    // 格式化开始时间和结束时间
    var startTimeString = that.formatDate(startTime);
    var endTimeString = that.formatDate(endTime);
  
    // 构造请求参数
    var requestData = {
      "start_time": startTimeString,
      "end_time": endTimeString
    };
  
    // 发送 POST 请求
    wx.request({
      url: 'https://server.itstudio.club:20443/appointment/all',
      method: 'POST',
      data: requestData,
      success: function(response) {
        console.log(response);
        if (response.statusCode === 200) {
          var data = response.data.data;
          var waitingAudit = [];
          var all = [];
          for (var i = 0; i < data.length; i++) {
            var item = data[i];
            if (item.is_checked === 0) {
              waitingAudit.push(item);
            }
            all.push(item);
          }
          that.setData({
            waitingAudit: waitingAudit,
            all: all
          });
        } else {
          console.log('请求失败');
        }
      },
      fail: function(error) {
        console.log(error);
      }
    });
  },
  
  // 格式化日期时间为字符串（YYYY-MM-DD HH:mm:ss）
  formatDate(date) {
    var year = date.getFullYear();
    var month = this.padZero(date.getMonth() + 1);
    var day = this.padZero(date.getDate());
    var hours = this.padZero(date.getHours());
    var minutes = this.padZero(date.getMinutes());
    var seconds = this.padZero(date.getSeconds());
    return year + '-' + month + '-' + day + ' ' + hours + ':' + minutes + ':' + seconds;
  },
  
  // 补零函数
  padZero(number) {
    return number < 10 ? '0' + number : number;
  }
});
