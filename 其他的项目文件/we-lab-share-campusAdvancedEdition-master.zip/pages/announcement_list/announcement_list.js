let announcementList = []
Page({
  data: {
    announcementList: [],
    kind:''
  },
  //跳转announcement
  go2Announcement(e) {
    if(this.data.kind=='announcements'){
      wx.navigateTo({
        url: '/pages/announcement/announcement?author=' + e.currentTarget.dataset.messages.author 
        + '&title=' + e.currentTarget.dataset.messages.title 
        + '&content=' + e.currentTarget.dataset.messages.content 
        + '&date=' + e.currentTarget.dataset.messages.date 
        + '&headImageSrc=' + e.currentTarget.dataset.messages.headImageSrc,
      })
    }else{
    } 
  },
  //获取announcements或者labNews数据，并放到announcementList
  getAnnouncements() {
    let that = this
    return new Promise((resolve, reject) => {
      wx.cloud.database().collection(that.data.kind).get().then(res => {
        let length = res.data.length
        for (let i = length-1; i > 0; --i) {
          const temp = {title: res.data[i].title, content: res.data[i].content, author: res.data[i].author, date: res.data[i].date, headImageSrc: res.data[i].headImageSrc, status:res.data[i].status}
          announcementList.push(temp)
          that.setData({
            announcementList
          })
        }
      })
    })
  },
  
  //下拉加载
  onReachBottom() {
    wx.showLoading({
      title: '加载中',
    })
    let that = this;
    var array = that.data.announcementList;
    wx.cloud.database().collection(that.data.kind).skip(array.length).get().then(res => {
      console.log("请求成功")
      if (res.data.length != 0) {
        let length = res.data.length
        for (let i = 0; i < length; ++i) {
          const temp = { title: res.data[i].title, content: res.data[i].content, author: res.data[i].author, date: res.data[i].date, headImageSrc: res.data[i].headImageSrc }
          array.push(temp)
          that.setData({
            announcementList: array
          })
          wx.hideLoading({
            success: (res) => {
              console.log("加载成功")
            }
          })
        }
      } else {
        wx.hideLoading()
        wx.showToast({
          icon: 'none',
          title: '再怎么加载也没有啦!',
        })
      }
    }).catch(err => {
      console.log("请求失败")
      wx.hideLoading()
      Toast.fail('加载失败')
    })
},

  onLoad(options) {
    announcementList = []
    this.setData({
      kind:options.kind,
      announcementList:[]
    })
    wx.showLoading({
      title: '加载中',
    })
    
    this.getAnnouncements().then((res)=>{
    })

    wx.hideLoading({
      success: (res) => {},
    })
  },
})