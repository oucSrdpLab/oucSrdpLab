import Dialog from 'miniprogram_npm/@vant/weapp/dialog/dialog';
import Toast from 'miniprogram_npm/@vant/weapp/toast/toast';
const app = getApp()
let feedback = []
Page({
  data: {
    title: '',
    content: '',
    feedback: []
  },

  //获取数据库的前20条反馈内容
  getFeedback() {
    let that = this
    return new Promise((resolve, reject) => {
      wx.cloud.database().collection("feedback").get().then(res => {
        let length = res.data.length
        for (let i = 0; i < length; ++i) {
          const temp = { title: res.data[i].title, content: res.data[i].content, name: res.data[i].name, identification: res.data[i].identification }
          feedback.push(temp)
          that.setData({
            feedback
          })
        }
      })
    })
  },

  //打开弹窗，写反馈
  write() {
    let that = this
    Dialog.confirm({
      title: "请填写反馈",
    }).then(() => {
      let title = that.data.title
      let content = that.data.content
      if (title == '' || content == '') {
        Toast.fail('请填写完整信息')
      } else {
        wx.showModal({
          title: '提示',
          content: '确定提交吗？',
          confirmColor: '#00a0e9',
          success: function (res) {
            let temp = { title: title, content: content, identification: app.globalData.identification, name: app.globalData.name }
            feedback.push(temp)

            //添加到数据库里
            wx.cloud.database().collection("feedback").add({
              data: {
                name: app.globalData.name,
                identification: app.globalData.identification,
                title: title,
                content: content
              }
            }).then(() => {
              Toast.success('提交成功')
              that.setData({
                feedback
              })
            }).catch(() => {
              Toast.fail('提交失败')
            })
          },
          fail: function (res) {
            Toast.fail('取消提交')
          }
        })

      }
    }
    )
  },

  //获取输入内容
  getTitle(e) {
    this.setData({
      title: e.detail.value
    })
  },
  getContent(e) {
    this.setData({
      content: e.detail.value
    })
  },

  onLoad(options) {
    //清空之前加载的feedback
    feedback = []
    this.data.feedback = []
    wx.showLoading({
      title: '加载中',
    })

    //一次最多20条
    this.getFeedback().then((res) => {
    })

    wx.hideLoading({
      success: (res) => { },
    })
  },

  onReady() {

  },
  onShow() {

  },
  onHide() {

  },
  onUnload() {

  },
  onPullDownRefresh() {

  },
  onReachBottom() {
    //实现分页,加载feedback中之后的20条数据
    wx.showLoading({
      title: '加载中',
    })
    let that = this;
    var array = that.data.feedback;
    wx.cloud.database().collection("feedback").skip(array.length).get().then(res => {
      console.log("请求成功")
      //数据库中的数据已经全部加载时弹窗显示已经加载完毕
      if (res.data.length != 0) {
        let length = res.data.length
        for (let i = 0; i < length; ++i) {
          const temp = { title: res.data[i].title, content: res.data[i].content, name: res.data[i].name, identification: res.data[i].identification }
          array.push(temp)
          that.setData({
            feedback: array
          })
          console.log("feedback", that.data.feedback)
          wx.hideLoading({
            success: (res) => {
              wx.showToast({
                title: '加载完成',
              })
            },
          })
        }
      } else {
        wx.hideLoading()
        wx.showToast({
          icon: 'none',
          title: '再怎么加载也没有啦!',
        })
      }
    }
    ).catch(() => {
      wx.hideLoading()
      Toast.fail('加载失败')
    }
    )
  },
  onShareAppMessage() {

  }
})