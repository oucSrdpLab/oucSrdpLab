import Dialog from 'miniprogram_npm/@vant/weapp/dialog/dialog';
import Toast from 'miniprogram_npm/@vant/weapp/toast/toast'
const app =getApp()
Page({
  data: {
    showPopup_start: false,
    showUntilTime: false,
    showPopup_until: false,
    curTime: new Date().getTime(),
    minDate: new Date().getTime(),

    //预约时间只能在一周内(暂定所有场所均这样) 
    maxDate: new Date().getTime() + 1000 * 60 * 60 * 24 * 7, 
 
    //filter控制预约最小时间间隔(暂定所有场所均这样) 
    filter(type, options) { 
      //设置时间间隔为30分钟 
      if (type === 'minute') { 
        return options.filter(option => option % 30 === 0); 
      } 
      return options; 
    }, 

    //formatter的功能是让时间选择器2022后面加个‘年’字，07后面加个‘月’字
    formatter(type, value) {
      if (type === 'year') {
        return `${value}年`;
      }
      if (type === 'month') {
        return `${value}月`;
      }
      return value;
    },
    //开始时间和结束时间
    startTime: "",
    startTime_str: "",
    untilTime: new Date().getTime(),
    untilTime_str: "",

    //学号姓名和预约原因
    stuNumber: "",
    applicantName: "",
    reason:'空',
    phone:'',

    //仪器信息
    equipmentName: "",
    equipmentPlace: "",
    equipmentID: "",
    capacity:0,

    //人数
    number:''
  },

  //点击预约时间展示popup(开始时间)
  showTime1() {
    this.setData({ showPopup_start: true })
  },

  //展示结束时间
  showTime2() {
    this.setData({ showPopup_until: true })
  },

  //点击其他地方关闭popup
  onClose() {
    this.setData({ showPopup_start: false, showPopup_until: false })
  },

  //让时间选择器选择预约时间更稳定
  onInput(event) {
    this.setData({
      currentDate: event.detail,
    });
  },

  //得到时间选择器选择的预约开始时间值
  confirm1(event) {
    // judgement是一个用来做判断的变量，如果时间是被预约过的话judgement=1
    let judgement = 0
    let that = this

    // 获取数据库里相应仪器被预约过的时间段
    wx.request({
      url: 'https://server.itstudio.club:20443/appointment/serch_by_equipment',
      method: 'POST',
      header: {
        'content-type': 'application/json' 
      },
      data: {
        equipment_id:that.data.equipmentID
      },
success(res) {
  console.log("confirm1", res)
  let orders = res.data.data
  let length = orders.length
  for (let i = 0; i < length; ++i) {
    let end = new Date(orders[i].end_time).getTime(); 
    let start = new Date(orders[i].start_time).getTime()
    let chose = new Date(event.detail).getTime()
    // 预约开始时间不能在他人预约时间段中
    if (chose >= start && chose <= end && orders[i].is_checked!=2) {
      judgement = 1
      Toast.fail("该时间段已被预约")
    }
    console.log("test2",start)
  }

  if (judgement == 0) {
    let date = new Date(event.detail)
    let startTime = date.getTime()

    // 转换时间戳
    let curDate = new Date(startTime)
    let curYear = curDate.getFullYear()
    let tempMonth = curDate.getMonth() + 1
    let curMonth = tempMonth < 10 ? "0" + tempMonth : tempMonth
    let curDay = curDate.getDate().toString().length == 1 ? ("0" + curDate.getDate()) : curDate.getDate()
    let curHour = curDate.getHours().toString().length == 1 ? ("0" + curDate.getHours()) : curDate.getHours()
    let curMinute = curDate.getMinutes().toString().length == 1 ? ("0" + curDate.getMinutes()) : curDate.getMinutes()
    let startTime_str = curYear + "-" + curMonth + "-" + curDay + " " + curHour + ":" + curMinute

    that.setData({
      startTime: startTime,
      startTime_str: startTime_str,
      showPopup_start: false,
      showUntilTime: true
    })
    console.log("startTime_str", that.data.startTime_str)
  }
},


      fail(err) {
        console.log("获取订单信息失败", err)
      }
    })
},

  //得到预约的结束时间
  confirm2(event) {
    let that = this
    let date = new Date(event.detail)
    let untilTime = date.getTime()
    let judgement = 0
    // 如果选择的时间小于当前时间，则提示用户
    if (date.getTime() < that.data.curTime) {
      Toast.fail("请选择当前时间以后的时间")
      return
    }
    // 如果选择的时间小于开始时间，则提示用户
    if (date.getTime() < that.data.startTime) {
      Toast.fail("请选择开始时间以后的时间")
      return
    }

    // 判断选择的结束时间是否符合规范（限制结束时间不能在别人的预约时间内，开始时间小于别人的开始时间但是结束时间大于别人的开始时间）
    wx.request({
      url: 'https://server.itstudio.club:20443/appointment/serch_by_equipment',
      method: 'POST',
      header: {
        'content-type': 'application/json' 
      },
      data: {
        equipment_id:that.data.equipmentID
      },
      success(res) {
        console.log("confirm2",res)
        let orders = res.data.data
        let length = orders.length
        for(let i = 0;i<length;++i){
          let end = new Date(orders[i].end_time).getTime(); 
          let start = new Date(orders[i].start_time).getTime()
          let chose = new Date(event.detail).getTime()
          if( ((chose>=start&&chose<=end)||(that.data.startTime<=start&&chose>=end)) && orders[i].is_checked!=2){
            judgement = 1
            Toast.fail("该时间段内有他人在使用")
          }
        }

        if(judgement == 0){    
          // 转换时间戳
          let curDate = new Date(untilTime)
          let curYear = curDate.getFullYear()
          let tempMonth = curDate.getMonth() + 1
          let curMonth = tempMonth < 10 ? "0" + tempMonth : tempMonth
          let curDay = curDate.getDate().toString().length == 1 ? ("0" + curDate.getDate()) : curDate.getDate()
          let curHour = curDate.getHours().toString().length == 1 ? ("0" + curDate.getHours()) : curDate.getHours()
          let curMinute = curDate.getMinutes().toString().length == 1 ? ("0" + curDate.getMinutes()) : curDate.getMinutes()
          let untilTime_str = curYear + "-" + curMonth + "-" + curDay + " " + curHour + ":" + curMinute

          that.setData({
            untilTime: untilTime,
            untilTime_str: untilTime_str,
            showPopup_until: false,
            showUntilTime: true
          })

          console.log("untilTime", that.data.untilTime)
          console.log("untilTime_str", that.data.untilTime_str)
        }
      },
      fail(err) {
        console.log("获取订单信息失败", err)
      }
    })
 },

  /*获取表单内容*/
  //获取姓名
  getInputName(e) {
    this.setData({
      applicantName: e.detail.value
    })
  },
  //获取学号/工号
  getInputNumber(e) {
    this.setData({
      stuNumber: e.detail.value
    })
  },
  //获取预约原因
  getReason(e){
    this.setData({
      reason:e.detail.value
    })
  },
  getNumber(e){
    this.setData({
      number:e.detail.value
    })
  },
  getPhone(e){
    this.setData({
      phone:e.detail.value
    })
  },

  submit() {
    let that = this
    // 输入信息有空时，弹出toast提示
    if (that.data.applicantName == '' || that.data.stuNumber == '' || that.data.startTime == '' || that.data.untilTime == '') {
      Toast.fail("信息不完整")
    } else if (that.data.number > that.data.capacity) {
      Toast.fail("预约人数超限")
    } else {
      wx.request({
        url: 'https://server.itstudio.club:20443/appointment/add',
        method: 'POST',
        header: {
          'content-type': 'application/json'
        },
        data: {
          user_id: app.globalData.user_id,
          equipment_id: that.data.equipmentID,
          start_time: that.data.startTime_str,
          end_time: that.data.untilTime_str,
          review_reason: that.data.reason,
          number_of_applicants: that.data.number,
          applicant_name: that.data.applicantName,
          applicant_student_id: that.data.stuNumber,
          telephone:that.data.phone,
          equipment_name:that.data.equipmentName
        },
        success(res) {
          console.log("添加成功", res)
          if (res.data.msg == "预约成功") {
            Toast.success("预约成功")
            wx.navigateTo({
              url: '/pages/finishedOrder/finishedOrder',
            })
          } else {
            // 根据错误信息显示相应的错误提示
            if (res.data.msg.includes('end_time不能为空')) {
              Toast.fail("结束时间不能为空")
            } else if (res.data.msg.includes('开始时间大于了结束时间')) {
              Toast.fail("开始时间大于了结束时间")
            } else if (res.data.msg.includes('equipment_id错误')) {
              Toast.fail("器材ID错误")
            } else {
              Toast.fail(res.data.msg)
            }
          }
        },
        fail(err) {
          Toast.fail("添加失败")
        }
      })
    }
  },
  
  
  

  onLoad(options) {
    let that = this;
    console.log("传来的仪器信息", options)
    that.setData({
      equipmentName: (options.equipmentName ? options.equipmentName : ''),
      equipmentPlace: (options.equipmentPlace ? options.equipmentPlace : ''),
      equipmentID: (options.equipmentID ? options.equipmentID : ''),
      capacity:options.capacity
    })
  },

})
