import Toast from 'miniprogram_npm/@vant/weapp/toast/toast';
Page({
  data: {
    things: [],
    name: '',
    itemName: "",
    academy: '',
    place: '',
    number: '',
    kind: '',
    brief:'',
  },
  //获取填写内容
  getName(e) {
    this.setData({
      name: e.detail.value
    })
  },
  getItemName(e) {
    this.setData({
      itemName: e.detail.value
    })
  },
  getAcademy(e) {
    this.setData({
      academy: e.detail.value
    })
  },
  getPlace(e) {
    this.setData({
      place: e.detail.value
    })
  },
  getNumber(e) {
    this.setData({
      number: e.detail.value
    })
  },
  getKind(e) {
    this.setData({
      kind: e.detail
    })
  },
  getBrief(e){
    this.setData({
      brief:e.detail.value
    })
  },

  // 在页面的js文件中的对应位置进行添加
  getImage() {
  let that = this
  wx.chooseMedia({
    count: 1,
    mediaType: ['image'],
    success(res) {
      wx.uploadFile({
        url: 'https://server.itstudio.club:20443/equipment/upload_image',
        filePath: res.tempFiles[0].tempFilePath,
        name: 'image',
        success(res) {
          console.log(res.data)
          const data = JSON.parse(res.data) 
          that.setData({
            image_url: data.image_url
          })
        },
        fail(res) {
          console.error(res.errMsg)
          Toast.fail("上传失败")
        }
      })
    }
  })
  },
  getImage1() {
  let that = this
  wx.chooseMedia({
    count: 1,
    mediaType: ['image'],
    success(res) {
      wx.uploadFile({
        url: 'https://server.itstudio.club:20443/equipment/upload_inside_image',
        filePath: res.tempFiles[0].tempFilePath,
        name: 'image',
        success(res) {
          console.log(res.data)
          const data = JSON.parse(res.data) 
          that.setData({
            image_inside_url: data.image_url
          })
        },
        fail(res) {
          console.error(res.errMsg)
          Toast.fail("上传失败")
        }
      })
    }
  })
  },

  //本地时间戳转换
  transTime(e){
      let curTime = e
      let curDate = new Date(curTime)
      
  
      let curYear = curDate.getFullYear()
      console.log("什么内容",curYear)
      let tempMonth = curDate.getMonth() + 1
      let curMonth = tempMonth < 10 ? "0" + tempMonth : tempMonth
      let curDay = curDate.getDate().toString().length == 1 ? ("0" + curDate.getDate()) : curDate.getDate()
      let curTime_str = curYear + "-" + curMonth + "-" + curDay
      return curTime_str
  },

  
  //添加仪器/活动室
add() {
  let that = this;
  let itemName = that.data.itemName;
  let place = that.data.place;
  let number = that.data.number;
  let kind = that.data.kind;
  let brief = that.data.brief;
  let image_url = that.data.image_url;
  let image_inside_url = that.data.image_inside_url;
  if (itemName == '' || place == '' || kind == '' || image_url == '') {
    Toast.fail('请填写完整信息');
  } else {
    wx.request({
      url: 'https://server.itstudio.club:20443/equipment/add',
      method: 'POST',
      data: {
        name: itemName,
        location: place,
        kind: kind,
        brief: brief,
        capacity: number,
        image_url: image_url,
        image_inside: image_inside_url
      },
      header: {
        'content-type': 'application/json'
      },
      success(res) {
        console.log("返回结果", res.data);
        Toast.success('提交成功');
        wx.redirectTo({
          url: '/pages/submitEquipment/submitEquipment',
          success() {
            // 关闭当前页面
            wx.navigateBack({
              delta: 1
            });
          }
        });
      },
      fail(err) {
        Toast.fail('提交失败');
        console.error(err);
      }
    });
  }
},

  
  onLoad(options) {

  },

})