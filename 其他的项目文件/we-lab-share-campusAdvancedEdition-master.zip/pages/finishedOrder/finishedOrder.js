Page({
  data: {
    steps:[
      {
        text:'提交订单',
      },
      {
        text:'等待审核',
      },
      {
        text:'按时签到'
      }
    ]
  },
  
  //回到首页
  goBack(){
    wx.switchTab({
      url: '/pages/index/index',
    })
  },
  
  onLoad(options) {

  },
  onReady() {

  },

})