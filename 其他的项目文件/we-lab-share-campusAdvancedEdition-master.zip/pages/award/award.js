import Dialog from 'miniprogram_npm/@vant/weapp/dialog/dialog';
import Toast from 'miniprogram_npm/@vant/weapp/toast/toast';
const app=getApp()
Page({
  data: {
    awardName:'',
    awardKind:'',
    date:'',
    institution:"",
    time:'',
    mine:[]
  },

  //打开弹窗——发消息
  write() {
    let that = this
    //删除弹窗中上一次的内容
    Dialog.confirm({
      title: "请填写奖项信息",
    }).then(() => {
      let name = that.data.awardName
      let kind = that.data.awardKind
      let date = that.data.time
      if (kind == '' || name == '') {
        Toast.fail('请填写完整信息')
      } else {
        //弹窗二次确认
        wx.showModal({
          title: '提示',
          content: '确认提交？',
          confirmColor: '#00a0e9',
          success: function (res) {
            if (res.confirm) {
              let temp = {
                date: date,
                level: kind,
                name: name,
                user_name: app.globalData.name,
                institution:that.data.institution
              };
              //添加到数据库里
              wx.request({
                url: 'https://server.itstudio.club:20443/collect/commit',
                method: 'POST',
                data: temp,
                success(res) {
                  // 请求成功处理逻辑
                  console.log(res.data);
                  Toast.success(res.data.msg);
                },
                fail(err) {
                  // 请求失败处理逻辑
                  console.error(err);
                  Toast.fail('请求失败');
                }
              });
            }
          },
          fail: function (res) {
            Toast.fail('取消提交')
          }
        })
      }
    }).catch(() => {})
  },
  
  //获取奖项名称
  getAwardName(e){
    this.setData({
      awardName:e.detail.value
    })
  },
  //获取奖项级别
  getAwardKind(e){
    console.log("test",e.detail)
    this.setData({
      awardKind:e.detail
    })
  },
  getTime(e) {
    const { value } = e.detail;
    const reg = /^\d{4}-\d{1,2}-\d{1,2}$/; // 正则表达式匹配日期格式
    if (value && !reg.test(value)) {
      Toast.fail('请输入正确的日期格式，例如：2021-10-1');
    } else {
      this.setData({
        time: value
      });
    }
  },
  getInstitution(e){
    this.setData({
      institution:e.detail.value
    })
  },
})