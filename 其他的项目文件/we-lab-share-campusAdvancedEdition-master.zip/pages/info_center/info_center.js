import Dialog from 'miniprogram_npm/@vant/weapp/dialog/dialog';
import Toast from 'miniprogram_npm/@vant/weapp/toast/toast';
let app = getApp()
let all = []
let study = []
let deal = []
let match = []
let mine = []
Page({
  data: {
    all: [],
    study: [],
    deal: [],
    match: [],
    mine:[],

    //控制弹窗
    title: '',
    content: '',
    kind: '',
    contact: '',
    //控制删除按钮
    openid:'',
    id:''
  },

  //获取信息数据（all,study,deal,match）
  getAll() {
    let that = this
    return new Promise((resolve, reject) => {
      wx.cloud.database().collection("info").get().then(res => {
        let length = res.data.length
        for (let i = 0; i < length; ++i) {
          const temp = { title: res.data[i].title, content: res.data[i].content, name: res.data[i].name, identification: res.data[i].identification, kind: res.data[i].kind, contact: res.data[i].contact,openid:res.data[i]._openid,_id:res.data[i]._id }
          all.push(temp)
          if (temp.kind == '学习') {
            study.push(temp)
          } else if (temp.kind == '交易') {
            deal.push(temp)
          } else if (temp.kind == '比赛') {
            match.push(temp)
          }
          //放到 我的 里
          if(res.data[i]._openid == app.globalData._openid){
            mine.push(temp)
          }
          that.setData({
            all,
            study,
            deal,
            match,
            mine
          })
        }
      })
    })
  },

  //打开弹窗——发消息
  write() {
    let that = this
    //删除弹窗中上一次的内容

    Dialog.confirm({
      title: "请填写消息",
    }).then(() => {
      let title = that.data.title
      let content = that.data.content
      let kind = that.data.kind
      let contact = that.data.contact
      if (title == '' || content == '' || kind == '' || contact == '') {
        Toast.fail('请填写完整信息')
      } else {
        //弹窗二次确认
        wx.showModal({
          title: '提示',
          content: '确认提交？',
          confirmColor: '#00a0e9',
          success: function (res) {
            if (res.confirm) {
              let temp = { title: title, content: content, identification: app.globalData.identification, name: app.globalData.name, kind: that.data.kind, contact: contact }
              all.push(temp)
              if (temp.kind == '学习') {
                study.push(temp)
              } else if (temp.kind == '交易') {
                deal.push(temp)
              } else if (temp.kind == '比赛') {
                match.push(temp)
              }
              mine.push(temp)
              //添加到数据库里
              wx.cloud.database().collection("info").add({
                data: {
                  name: app.globalData.name,
                  identification: app.globalData.identification,
                  title: title,
                  content: content,
                  kind: kind,
                  contact: contact
                }
              }).then(() => {
                Toast.success('提交成功')
                ++app.globalData.count
                wx.setStorageSync('count', app.globalData.count)
                that.setData({
                  all,
                  study,
                  deal,
                  match,
                  mine,
                  //删除弹窗在本地中存的内容
                  title: '',
                  content: '',
                  kind: '',
                  contact: ''
                })
              }).catch(() => {
                Toast.fail('提交失败')
              })
            }
          },
          fail: function (res) {
            Toast.fail('取消提交')
          }
        })
      }
    }
    ).catch(()=>{
    })
  },

  //获取填写内容
  getTitle(e) {
    this.setData({
      title: e.detail.value
    })
  },
  getContact(e) {
    this.setData({
      contact: e.detail.value
    })
  },
  getContent(e) {
    this.setData({
      content: e.detail.value
    })
  },
  getKind(e) {
    this.setData({
      kind: e.detail
    })
  },

  //删除消息
  delete(e){
    let that = this
    wx.showModal({
      title:"确认删除吗",
      success(res){
        wx.cloud.callFunction({
          name:"deleteInfo",
          data:{
            content:e.currentTarget.dataset.messages.content,
            _openid:app.globalData._openid
          }
        }).then((res)=>{
          let all = that.data.all
          console.log(all)
          let index1 = all.findIndex(item => item.content == e.currentTarget.dataset.messages.content)
          all.splice(index1, 1)
          console.log(all)
          
          let mine = that.data.mine
          let index2 = mine.findIndex(item=>item.content == e.currentTarget.dataset.messages.content)
          mine.splice(index2,1)
          that.setData({
            all,
            mine
          })
        })
      }
    })
  },

  //举报
  indict(e){
    if(app.globalData._openid=='oGw-z5WKrHhM8AL-D2OofigR50CI'){
      wx.requestSubscribeMessage({
        tmplIds: ["TYXQcQMZka9KsOrIGz977PY0lbW4k0JxIayWBDW-4A4"],
        success(res){
        },
        fail(res){
          console.log(res)
        }
      })
    }   
    wx.showModal({
      title:"确认举报吗",
      editable:true,
      placeholderText:"举报原因",
      success(res){
        if(!res.content){
          Toast.fail("请输入举报原因")          
        }else{
          wx.cloud.callFunction({
            name:'sendIndict',
            data:{
              reason:res.content,
              title:e.currentTarget.dataset.messages.title,
              content:e.currentTarget.dataset.messages.content,
              name:e.currentTarget.dataset.messages.name,
              identification:e.currentTarget.dataset.messages.identification,
              openid:"oGw-z5WKrHhM8AL-D2OofigR50CI",
            }
          }).then(res=>{
            console.log("进来没",res)
          })
        }
      },
      fail(res){
        Toast.fail("取消举报")
      }
    })
  },

  onReachBottom() {
    //实现分页,加载feedback中之后的20条数据
    wx.showLoading({
      title: '加载中',
    })
    let that = this;
    var all = that.data.all;
    var study = that.data.study
    var deal = that.data.deal
    var match = that.data.match
    wx.cloud.database().collection("info").skip(array.length).get().then(res => {
      console.log("请求成功")
      //数据库中的数据已经全部加载时弹窗显示已经加载完毕
      if (res.data.length != 0) {
        let length = res.data.length
        for (let i = 0; i < length; ++i) {
          const temp = { title: res.data[i].title, content: res.data[i].content, name: res.data[i].name, identification: res.data[i].identification, kind: res.data[i].kind, contact: res.data[i].contact,openid:res.data[i]._openid,_id:res.data[i]._id }
          all.push(temp)
          if (temp.kind == '学习') {
            study.push(temp)
          } else if (temp.kind == '交易') {
            deal.push(temp)
          } else if (temp.kind == '比赛') {
            match.push(temp)
          }
          if(res.data[i]._openid==app.globalData._openid){
            mine.push(temp)
          }
          that.setData({
            all,
            study,
            deal,
            match,
            mine
          })
          wx.hideLoading({
            success: (res) => {
              wx.showToast({
                title: '加载完成',
              })
            },
          })
        }
      } else {
        wx.hideLoading()
        wx.showToast({
          icon: 'none',
          title: '再怎么加载也没有啦!',
        })
      }
    }
    ).catch(() => {
      wx.hideLoading()
      Toast.fail('加载失败')
    }
    )
  },

  onLoad(options) {
    let id = app.globalData.identification
    let oepnid = app.globalData.openid
    this.setData({
      id,
      oepnid
    })
    all = []
    study = []
    deal = []
    match = []
    mine = []
    this.data.all = []
    this.data.study = []
    this.data.deal = []
    this.data.match = []
    this.data.mine = []
    wx.showLoading({
      title: '加载中',
    })
    this.getAll().then((res) => {
    })
    wx.hideLoading({
      success: (res) => { },
    })
  },

  onReady() { },
  onShow() { },
  onHide() { },
  onUnload() { },
  onPullDownRefresh() { },
  onShareAppMessage() { }
})