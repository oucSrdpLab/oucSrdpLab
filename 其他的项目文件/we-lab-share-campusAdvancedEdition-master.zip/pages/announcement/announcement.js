Page({
  data: {
    author: '管理员A',
    title: '关于近期实验器具调整的公告',
    content: 'aaaaa\nbbbbb\nccccc',
    date: "2022-07-22",
    // headImageSrc: 'cloud://welab-0g7lv9me1d812eb0.7765-welab-0g7lv9me1d812eb0-1311783855/announcement_background/test.jpg',
  },

  contactToUS() {
    //展示联系方式(开发人员的)
    wx.showModal({
      title: '联系方式',
      content: '邮箱：xxx@qq.com\r\n手机: xxx',
      showCancel: false,
    })
  },
  onLoad(options) {
    //替换掉数据库中content的"\n"为换行符
    let c = options.content.replace("\\n","\n")
    this.setData({
      author: options.author,
      title: options.title,
      content: c,
      date: options.date,
      headImageSrc: options.headImageSrc,
    })
  },

})