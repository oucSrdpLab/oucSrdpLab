import Dialog from 'miniprogram_npm/@vant/weapp/dialog/dialog';
const app = getApp()
Page({
  data: {
    //全部订单
    all: [],
    //待审核
    waitingAudit: [],
    //已审核
    audited: [],
    //已完成
    finished: [],

    showTextarea: false,
    changedOrderNumber: 0,

    //身份查找
    identification: '',
    name: '',

    //某个订单的openid
    orderOpenId: '',
    //拒绝理由
    reason: ''
  },


transTime(event) {
  let curTime = BigInt(event);
  
  // 将 BigInt 转换为字符串，然后再转换为 Number 类型
  let timestamp = parseInt(curTime.toString());
  
  // 使用新的 timestamp 参数创建 Date 对象 
  let curDate = new Date(timestamp);

  let curYear = curDate.getFullYear();
  let tempMonth = curDate.getMonth() + 1;
  let curMonth = tempMonth < 10 ? "0" + tempMonth : tempMonth;
  let curDay = curDate.getDate().toString().length == 1 ? ("0" + curDate.getDate()) : curDate.getDate();
  let curHour = curDate.getHours().toString().length == 1 ? ("0" + curDate.getHours()) : curDate.getHours();
  let curMinute = curDate.getMinutes().toString().length == 1 ? ("0" + curDate.getMinutes()) : curDate.getMinutes();
  let curTime_str = curYear + "-" + curMonth + "-" + curDay + " " + curHour + ":" + curMinute;
  return curTime_str;
},

  //删除订单
  deleteOrder(e) {
    let that = this
    let idOfcurOrder = e.currentTarget.dataset.messages.appointment_id
    const apiUrl = 'https://server.itstudio.club:20443/appointment/delete'
    // 发送 HTTP 请求删除订单
    wx.request({
      url: apiUrl,
      method: 'POST',
      data: { appointment_id: idOfcurOrder },
      success: (res) => {
        console.log("删除订单成功")
        //从all中删除该订单
        let all = that.data.all
        let audited = that.data.audited
        let waitingAudit = that.data.waitingAudit
        let finished = that.data.finished
        let index = all.findIndex(item => item.appointment_id == idOfcurOrder)
        all.splice(index, 1)
        audited.splice(index,1)
        waitingAudit.splice(index,1)
        finished.splice(index,1)
        that.setData({
          all: all,
          audited:audited,
          waitingAudit:waitingAudit,
          finished:finished
        })
      },
      fail: (err) => {
        console.error("删除订单失败:", err)
      }
    })
  },
  
  

//显示订单信息
setConcretOrders: function() {
  var that = this;
  wx.request({
    url: 'https://server.itstudio.club:20443/appointment/serch_by_user',
    method:"POST",
    data: {
      user_id: app.globalData.user_id,
    },
    header: {
      'content-type': 'application/json' 
    },
    success: function(res) {
      console.log("test",res.data)
      var orders = res.data.data;
      var all = [];
      var waitingAudit = [];
      var audited = [];
      var finished = [];
      for (var i = 0; i < orders.length; i++) {
        var order = orders[i];
        let end = new Date(order.end_time).getTime()
        if (order.is_sign == false&&end < Date.now()) {
          waitingAudit.push(order);
        } else if (order.is_sign == false&&end > Date.now()) {
          audited.push(order);
        } else if (order.is_sign == true) {
          finished.push(order);
        }
        all.push(order);
      }
      that.setData({
        all: all,
        waitingAudit: waitingAudit,
        audited: audited,
        finished: finished,
      });
    },
    fail: function(res) {
      console.log('请求订单数据失败');
    }
  });
},

  changeStatus() {
    let that = this
    let waitingAudit = [];
    let audited = [];
    let finished = [];
    let canceled = [];
    //设置all中订单状态
    for (let i in that.data.all) {
      if (that.data.all[i].status == '待审核'||that.data.all[i].status =="待签到") {
        waitingAudit.push(that.data.all[i]);
      }
    }
    that.setData({
      waitingAudit
    });
    //已审核+审核被拒绝
    for (let i in that.data.all) {
      if (that.data.all[i].status == '已审核' || that.data.all[i].status == '预约被拒绝') {
        audited.push(that.data.all[i]);
      }
    }
    that.setData({
      audited
    });
    //已结束
    for (let i in that.data.all) {
      if (that.data.all[i].status == '已结束') {
        finished.push(that.data.all[i]);
      }
    }
    that.setData({
      finished
    });
    //已取消
    for (let i in that.data.all) {
      if (that.data.all[i].status == '已取消') {
        canceled.push(that.data.all[i]);
      }
    }
    that.setData({
      canceled
    });
  },

  onLoad(options) {
    //更新当前openid的订单
    this.setConcretOrders()
  },
})