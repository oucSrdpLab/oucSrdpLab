Page({
  data: {
    curTitle: "",
    curName: "",
    curPlace: "",
    curCapacity: "",
    curId: "",
    curImage:"",
    brief:"",
    inside:"",
    show:false,
    //已被预约的时间
    comprehension:[],
    reservedTime:[],
    startTime:"",
    endTime:"",
    choseDate: '', // 选择的时间
  },

  //点击我的预约，跳转到myOrder界面
  go2myOrder() {
    wx.navigateTo({
      url: '/pages/myOrder/myOrder',
    })
  },

  //点击立刻预约，跳转到reservation界面
  go2reservation() {
    wx.navigateTo({
      url: '/pages/reservation/reservation?equipmentName=' + this.data.curName 
      + '&equipmentPlace=' 
      + this.data.curPlace 
      + '&equipmentID=' 
      + this.data.curId
      +'&capacity='
      +this.data.curCapacity
    })
  },

  //本地写了个时间戳函数
  transTime(event) {
    let curTime = BigInt(event);
    
    // 将 BigInt 转换为字符串，然后再转换为 Number 类型
    let timestamp = parseInt(curTime.toString());
    
    // 使用新的 timestamp 参数创建 Date 对象 
    let curDate = new Date(timestamp);
  
    let curYear = curDate.getFullYear();
    let tempMonth = curDate.getMonth() + 1;
    let curMonth = tempMonth < 10 ? "0" + tempMonth : tempMonth;
    let curDay = curDate.getDate().toString().length == 1 ? ("0" + curDate.getDate()) : curDate.getDate();
    let curHour = curDate.getHours().toString().length == 1 ? ("0" + curDate.getHours()) : curDate.getHours();
    let curMinute = curDate.getMinutes().toString().length == 1 ? ("0" + curDate.getMinutes()) : curDate.getMinutes();
    let curTime_str = curYear + "-" + curMonth + "-" + curDay + " " + curHour + ":" + curMinute;
    return curTime_str;
  },
  
  onClose(){
    this.setData({
      show:false
    })
  },

  checkImage(){
    this.setData({
      show:true
    })
  },

  onLoad(options) {
    let that = this
    that.setData({
      curTitle: options.curName,
      curName: options.curName,
      curPlace: options.curPlace,
      curCapacity: options.curCapacity,
      curId: options.curId,
      curImage:options.curImage,
      inside:options.inside,
      brief:options.brief,
      disable:options.disable
    })
    wx.request({
      url: 'https://server.itstudio.club:20443/appointment/serch_by_equipment',
      method: 'POST',
      data:{
        "equipment_id":options.curId
      },
      header: {
        'content-type': 'application/json'
      },
      success(res) {
        const orders = res.data.data
        const reservedTime = []
        for(let i = 0;i<orders.length;++i){
          const curOrder = orders[i]
          console.log("test",curOrder)
          let end = new Date(curOrder.end_time).getTime()
          if (curOrder.equipment_id == that.data.curId && end > Date.now()&& curOrder.is_checked!=2) {
            reservedTime.push({
              startTime: curOrder.start_time,
              untilTime: curOrder.end_time
            });
          }
        }
        that.setData({
          reservedTime
        })
      },
      fail(err) {
        console.error('获取订单失败', err)
      }
    })
   },

})