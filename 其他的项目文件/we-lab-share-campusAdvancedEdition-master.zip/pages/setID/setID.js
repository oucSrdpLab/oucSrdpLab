const app = getApp()
import Toast from 'miniprogram_npm/@vant/weapp/toast/toast'
Page({
  data: {
    //学号
    number: "",
    //密码
    password: "",
    password2:"",
    name:"",
    code:'',
    email:''
  },

  /* 获取输入框的内容 */
  //获取姓名(姓名赋值给了全局变量)
  blurName(e) {
    this.setData({
      name:e.detail.value
    })
    app.globalData.name = e.detail.value
  },

  //获取密码
  blurPassword(e) {
    this.setData({
      password: e.detail.value
    })
  },
  blurPassword2(e){
    this.setData({
      password2:e.detail.value
    })
  },
  //获取学号
  blurNumber(e) {
    let number = e.detail.value;
    let identification = app.globalData.identification;
    this.setData({
      number: number
    })
  
    if (number.length == 7) {
      identification = "teacher";
    } else {
      identification = "student";
    }
  
    app.globalData.identification = identification;
  },
  
  blurEmail(e){
    this.setData({
      email: e.detail.value
    })
  },
  blurCode(e){
    this.setData({
      code: e.detail.value
    })
  },

  // 获取验证码
getCode() {
  let that = this;
  // 限制输入不能为空
  if (that.data.email === '') {
    Toast.fail('请输入邮箱');
    return;
  }

  wx.request({
    url: 'https://server.itstudio.club:20443/user/send_code_by_email',
    method: 'POST',
    header: {
      'content-type': 'application/json'
    },
    data: {
      email: that.data.email
    },
    success(res) {
      console.log('结果', res);
      if (res.statusCode === 200 && res.data.code === 0) {
        // 发送成功，获取验证码
        const code = res.data.data.code;
        that.setData({
          code: code
        });
        Toast.success(res.data);
      } else {
        Toast.fail(res.data);
      }
    },
    fail(err) {
      console.error(err);
      Toast.fail('请求失败');
    }
  });
},

  //按钮绑定
  binding() {
    let that = this
    console.log("test",that.data.number,that.data.password,that.data.name,that.data.password2)
    //限制输入不能为空
    if (that.data.number == '' || that.data.password == '' || that.data.name == '' ) {
      Toast.fail("信息不完整")
    } else {
      //储存登录状态
      let register = {name: app.globalData.name,certificated: true,identification: "student"}
      wx.setStorageSync('token', register)
      wx.request({
        url: 'https://server.itstudio.club:20443/user/register', 
        method:'POST',
        header: {
          'content-type': 'application/json' 
        },
        data:{
          username:app.globalData.name,
          password:that.data.password,
          phone:that.data.number,
          identification:app.globalData.identification,
          email:that.data.email,
        },
        success(res) {
            // 将注册信息存储在本地缓存中
   wx.setStorageSync('token', {
    name: res.data.username,
    identification: res.data.identification,
    number: res.data.phone,
    uer_id: res.data.uer_id
  });
          app.globalData.identification=res.data.identification
          app.globalData.number=res.data.phone
          app.globalData.name=res.data.username
          app.globalData.user_id=res.data.user_id
          console.log("结果",res)
          wx.switchTab({
            url: '/pages/index/index',
          })
        }
      })
    }
  },

})