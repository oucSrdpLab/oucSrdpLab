const app = getApp()
Page({
  data: {
    name : "请登录",
    id : "点击卡片登录",
    curOpenID:"",
    judgement:0,
    blackList:0
  },

  go2Login(){
    wx.navigateTo({
      url: '../login/login',
    })
  },

  go2checkOrder(){
    wx.navigateTo({
      url: '../checkOrder/checkOrder',
    })
  },

  //跳转我的订单
  ord_detail:function(){
    //this.subscribe()
    wx.navigateTo({
      url: '/pages/myOrder/myOrder?curOpenId=' + this.data.curOpenID,
    })
  },

  //跳转上传仪器、活动室
  go2SubmitEquipment(){
    //this.subscribe()
    wx.navigateTo({
      url: '/pages/submitEquipment/submitEquipment',
    })
  },

  //跳转认证身份
  go2checkID(){
    wx.navigateTo({
      url: '/pages/checkID/checkID',
    })
  },

  //内含显示根据老师身份显示上传仪器和活动室
  onLoad(options) {
    let that = this
    this.setData({
      name:app.globalData.name,
      id:app.globalData.identification
    })
    if(this.data.id=="teacher"||this.data.id=="manager"){
      this.setData({
        judgement:1
      })
    }
  },

  onHide() {
    wx.navigateBack({
      delta: 1  // 返回上一个页面
    })
  }, 
})
