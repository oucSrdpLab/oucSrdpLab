const app = getApp()
Page({
  data: {
    username: '',
    pass1: ''
  },

  // 获取输入的账号
  getusername(event) {
    this.setData({
      username: event.detail.value
    })
  },

  // 获取输入的密码
  getpass1(event) {
    this.setData({
      pass1: event.detail.value
    })
  },

  // 点击登陆
  login() {
    let username = this.data.username
    let pass1 = this.data.pass1
    if (username == '' || pass1 == '') {
      wx.showToast({
        title: '用户或密码不能为空',
        icon: 'none',
        duration: 2000
      })
    } else {
      // 登录
      wx.request({
        url: "https://server.itstudio.club:20443/user/login", // 登录接口的URL
        method: 'POST',
        data: {
          username: username,
          password: pass1
        },
        header: {
          'content-type': 'application/json'
        },
        success(res) {
          // 登录成功的处理逻辑
          console.log(res.data)
          if (res.data.msg == '登陆成功') {
            // 登录成功，处理跳转等操作
            wx.setStorageSync('token', {
              name: res.data.username,
              identification: res.data.identification,
              number: res.data.phone,
              user_id: res.data.user_id
            });
            app.globalData.number=res.data.phone
            app.globalData.identification=res.data.identification
            app.globalData.name=res.data.username
            app.globalData.user_id=res.data.user_id
            wx.switchTab({
              url: '/pages/index/index',
            })
          } else {
            // 登录失败，显示错误信息
            wx.showToast({
              title: res.data.msg,
              icon: 'none',
              duration: 2000
            })
          }
        },
        fail(err) {
          // 请求失败的处理逻辑
          console.error("test",err)
          wx.showToast({
            title: '请求失败',
            icon: 'none',
            duration: 2000
          })
        }
      })
    }
  },

  // 点击绑定身份，跳转绑定身份
  setID() {
    wx.navigateTo({
      url: '/pages/setID/setID',
    })
  },
})
